<?php
session_start();

$conn = new mysqli("localhost", "root", "", "gestione rifiuti");
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

function mostraErrore($messaggio) {
    ?>
    <!DOCTYPE html>
    <html lang="it">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Errore Login</title>
        <link rel="stylesheet" href="css/style.css" />
    </head>
    <body>
        <div class="container">
            <h1>Errore di login</h1>
            <p style="color: red; font-weight: bold; margin-bottom: 20px;"><?php echo htmlspecialchars($messaggio); ?></p>
            <a href="login.html">Riprova il login</a>
        </div>
    </body>
    </html>
    <?php
    exit();
}

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (!$email || !$password) {
    mostraErrore("Compila tutti i campi.");
}

$sql = "SELECT id, email, password, ruolo, nome, cognome FROM utenti WHERE email = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    mostraErrore("Errore nella preparazione della query.");
}

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();

    if (password_verify($password, $row['password'])) {
        $_SESSION['id'] = $row['id'];           // <-- aggiunto id
        $_SESSION['email'] = $row['email'];
        $_SESSION['ruolo'] = $row['ruolo'];

        if (isset($stmt) && $stmt instanceof mysqli_stmt) {
            $stmt->close();
        }
        $conn->close();

        if ($row['ruolo'] === 'amministratore') {
            header("Location: dashboard_amministratore.php");
        } else {
            header("Location: dashboard_dipendente.php");
        }
        exit();
    } else {
        if (isset($stmt) && $stmt instanceof mysqli_stmt) {
            $stmt->close();
        }
        $conn->close();
        mostraErrore("Password errata.");
    }
} else {
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        $stmt->close();
    }
    $conn->close();
    mostraErrore("Email non trovata.");
}
?>
