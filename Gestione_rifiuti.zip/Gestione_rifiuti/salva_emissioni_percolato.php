<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'dipendente') {
    header("Location: login.html");
    exit();
}

include 'db_connection.php'; // connessione $conn

$conferimento_id = $_POST['conferimento_id'] ?? null;
$data_rilevazione = $_POST['data_rilevazione'] ?? null;
$co2_emessa = $_POST['co2_emessa'] ?? null;
$percolato_rilevato = $_POST['percolato_rilevato'] ?? null;
$note = $_POST['note'] ?? null;

if (!$conferimento_id || !$data_rilevazione || $co2_emessa === null || $percolato_rilevato === null) {
    $messaggio = "Errore: campi obbligatori mancanti.";
    $success = false;
} else {
    $dipendente_email = $_SESSION['email'];
    $sqlCheck = "SELECT c.ID_conferimento FROM conferimenti c 
                 JOIN utenti u ON c.dipendente_id = u.id 
                 WHERE c.ID_conferimento = ? AND u.email = ?";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("is", $conferimento_id, $dipendente_email);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

    if ($resultCheck->num_rows === 0) {
        $messaggio = "Errore: conferimento non valido o non autorizzato.";
        $success = false;
    } else {
        $sqlInsert = "INSERT INTO monitoraggio_emissioni_percolato 
                      (conferimento_id, data_rilevazione, co2_emessa, percolato_rilevato, note) 
                      VALUES (?, ?, ?, ?, ?)";
        $stmtInsert = $conn->prepare($sqlInsert);
        $stmtInsert->bind_param("isdds", $conferimento_id, $data_rilevazione, $co2_emessa, $percolato_rilevato, $note);
        $ok = $stmtInsert->execute();

        if ($ok) {
            $messaggio = "Salvataggio avvenuto con successo!";
            $success = true;
        } else {
            $messaggio = "Errore nell'inserimento: " . $conn->error;
            $success = false;
        }
        $stmtInsert->close();
    }
    $stmtCheck->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Esito Salvataggio</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body class="dashboard-dipendente">
    <div class="container">
        <div class="<?php echo $success ? 'box-success' : 'box-error'; ?>">
            <h2><?php echo $success ? "Successo" : "Errore"; ?></h2>
            <p><?php echo htmlspecialchars($messaggio); ?></p>
            <a class="btn" href="emissioni_percolato.php">Torna a emissioni e percolato</a>
        </div>
    </div>
</body>
</html>
