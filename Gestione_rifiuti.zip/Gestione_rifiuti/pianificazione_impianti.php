<?php
// pianificazione_impianti.php

// Controllo sessione o permessi qui (se serve)
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Pianificazione e manutenzione impianti</title>
    <link rel="stylesheet" href="css/style.css" />
    <style>
      /* Stile specifico per i pulsanti di questa pagina */
      .btn-pianificazione {
        padding: 16px 24px;
        font-size: 18px;
        width: 100%;
        max-width: 400px;
        margin: 0 auto;
        background-color: #2d6a4f;
        color: #fff;
        border: none;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
        cursor: pointer;
        transition: background-color 0.3s, transform 0.2s;
      }

      .btn-pianificazione:hover {
        background-color: #1b4332;
        transform: translateY(-2px);
      }
    </style>
</head>
<body class="dashboard-amministratore">
    <div class="back-dashboard">
        <a href="dashboard_amministratore.php" title="Torna alla Dashboard">← Dashboard</a>
    </div>

  <div class="container" style="background-color: rgba(255, 255, 255, 0.92);">
    <h1>Pianificazione turni impianti e manutenzione </h1>

    <div style="display: flex; flex-direction: column; gap: 15px; margin-top: 30px;">
      <form action="nuova_manutenzione.php" method="get">
        <button type="submit" class="btn btn-pianificazione">Nuova Manutenzione</button>
      </form>

      <form action="visualizza_calendario.php" method="get">
        <button type="submit" class="btn btn-pianificazione">Visualizza Calendario</button>
      </form>

      <form action="storico_manutenzioni.php" method="get">
        <button type="submit" class="btn btn-pianificazione">Storico Manutenzioni</button>
      </form>

      <!-- ✅ Nuovo pulsante per la gestione della turnazione -->
      <form action="turnazione_impianti.php" method="get">
        <button type="submit" class="btn btn-pianificazione">Gestione Turnazione Impianti</button>
      </form>

      <!-- ✅ Nuovo pulsante per visualizzare le turnazioni -->
      <form action="visualizza_turnazioni.php" method="get">
        <button type="submit" class="btn btn-pianificazione">Visualizza Turnazioni</button>
      </form>
    </div>
  </div>

</body>
</html>
