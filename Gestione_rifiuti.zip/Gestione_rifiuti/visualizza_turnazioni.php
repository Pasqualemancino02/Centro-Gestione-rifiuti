<?php
session_start();
require_once 'db_connection.php';

// Carica lista impianti attivi per filtro
$impianti = [];
$sql_impianti = "SELECT ID_impianto, nome FROM impianti WHERE stato = 'attivo' ORDER BY nome";
$result_impianti = $conn->query($sql_impianti);
if ($result_impianti) {
    while ($row = $result_impianti->fetch_assoc()) {
        $impianti[] = $row;
    }
}

// Prendi valori filtro da GET (o default vuoto)
$filtro_impianto = $_GET['filtro_impianto'] ?? '';
$filtro_data_inizio_da = $_GET['filtro_data_inizio_da'] ?? '';

// Costruisci query base
$sql = "SELECT t.id, i.nome AS nome_impianto, t.data_inizio, t.data_fine, t.tipo_turno, t.note
        FROM turnazioni t
        JOIN impianti i ON t.id_impianto = i.ID_impianto";

// Costruisci condizioni filtro
$conditions = [];
$params = [];
$types = '';

if ($filtro_impianto !== '') {
    $conditions[] = 't.id_impianto = ?';
    $params[] = $filtro_impianto;
    $types .= 'i';
}

if ($filtro_data_inizio_da !== '') {
    $conditions[] = 't.data_inizio >= ?';
    $params[] = $filtro_data_inizio_da;
    $types .= 's';
}

if (count($conditions) > 0) {
    $sql .= " WHERE " . implode(' AND ', $conditions);
}

$sql .= " ORDER BY t.data_inizio ASC";

$stmt = $conn->prepare($sql);

if ($stmt) {
    if (count($params) > 0) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    die("Errore nella preparazione della query.");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8" />
  <title>Visualizza Turnazioni Impianti</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    .container {
      max-width: 900px;
      margin: 40px auto;
      background-color: rgba(255,255,255,0.9);
      padding: 20px;
      border-radius: 8px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: left;
    }
    th {
      background-color: #2d6a4f;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    .back-dashboard {
      margin-bottom: 20px;
    }

    form.filter-form {
      display: flex;
      gap: 15px;
      flex-wrap: wrap;
      align-items: center;
      align-self: flex-end;
      margin-bottom: 20px;
    }
    form.filter-form label {
      font-weight: 600;
      display: block;
      margin-bottom: 4px;
    }
    form.filter-form .field-group {
      display: flex;
      flex-direction: column;
    }
    form.filter-form select,
    form.filter-form input[type="date"] {
      padding: 6px 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 6px;
      width: 180px;
      box-sizing: border-box;
      transition: border-color 0.3s;
    }

    form.filter-form button {
      padding: 8px 20px;
      font-size: 14px;
      background-color: #2d6a4f;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: background-color 0.3s;
      height: 34px;
    }
    form.filter-form button:hover {
      background-color: #1b4332;
    }

    /* Spaziatura tra i bottoni */
    form.filter-form button + button {
      margin-left: 10px;
    }
  </style>

  <!-- jsPDF + AutoTable -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
</head>
<body class="dashboard-amministratore">

<div class="back-dashboard">
  <a href="pianificazione_impianti.php" title="Torna a Gestione Turnazioni">← Torna indietro</a>
</div>

<div class="container">
  <h1>Elenco Turnazioni Impianti</h1>

  <!-- Form filtro -->
  <form method="get" action="visualizza_turnazioni.php" class="filter-form" autocomplete="off">
    <div class="field-group">
      <label for="filtro_impianto">Filtra per Impianto</label>
      <select name="filtro_impianto" id="filtro_impianto">
        <option value="">-- Tutti gli Impianti --</option>
        <?php foreach ($impianti as $impianto): ?>
          <option value="<?php echo $impianto['ID_impianto']; ?>"
            <?php if ($impianto['ID_impianto'] == $filtro_impianto) echo 'selected'; ?>>
            <?php echo htmlspecialchars($impianto['nome']); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="field-group">
      <label for="filtro_data_inizio_da">Data Inizio da</label>
      <input type="date" id="filtro_data_inizio_da" name="filtro_data_inizio_da" value="<?php echo htmlspecialchars($filtro_data_inizio_da); ?>" />
    </div>

    <button type="submit">Filtra</button>
    <button type="button" id="reset-filters">Reset</button>
    <button type="button" id="download-pdf">Scarica PDF </button>
  </form>

  <?php if ($result && $result->num_rows > 0): ?>
    <table id="turnazioni-table">
      <thead>
        <tr>
          <th>Impianto</th>
          <th>Data Inizio</th>
          <th>Data Fine</th>
          <th>Tipo Turno</th>
          <th>Note</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?php echo htmlspecialchars($row['nome_impianto']); ?></td>
            <td><?php echo htmlspecialchars($row['data_inizio']); ?></td>
            <td><?php echo htmlspecialchars($row['data_fine']); ?></td>
            <td><?php echo htmlspecialchars(ucfirst($row['tipo_turno'])); ?></td>
            <td><?php echo nl2br(htmlspecialchars($row['note'])); ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p>Nessuna turnazione trovata.</p>
  <?php endif; ?>
</div>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    // PDF export
    const btn = document.getElementById("download-pdf");
    if (btn) {
      btn.addEventListener("click", function () {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        const table = document.getElementById("turnazioni-table");
        const rows = Array.from(table.querySelectorAll("tbody tr")).map(tr => {
          return Array.from(tr.querySelectorAll("td")).map(td => td.innerText.trim());
        });

        const headers = Array.from(table.querySelectorAll("thead th")).map(th => th.innerText.trim());

        doc.setFontSize(14);
        doc.text("Report Turnazioni Impianti", 14, 15);
        doc.setFontSize(10);
        const now = new Date().toLocaleString("it-IT");
        doc.text("Generato il: " + now, 14, 22);

        doc.autoTable({
          startY: 28,
          head: [headers],
          body: rows,
          styles: { fontSize: 9 },
          headStyles: { fillColor: [45, 106, 79] },
          alternateRowStyles: { fillColor: [240, 249, 244] }
        });

        doc.save("turnazioni_impianti.pdf");
      });
    }

    // Reset filtri
    document.getElementById('reset-filters').addEventListener('click', function() {
      document.getElementById('filtro_impianto').value = '';
      document.getElementById('filtro_data_inizio_da').value = '';
      this.form.submit();
    });
  });
</script>

</body>
</html>
