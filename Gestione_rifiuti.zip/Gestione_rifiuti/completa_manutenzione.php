<?php
session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);
    $utente = isset($_SESSION['username']) ? $_SESSION['username'] : 'sconosciuto';

    // Recupera dati manutenzione prima della modifica
    $stmt = $conn->prepare("SELECT * FROM manutenzioni WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows !== 1) {
        die("Manutenzione non trovata.");
    }
    $manutenzione = $result->fetch_assoc();
    $stmt->close();

    $dati_precedenti = json_encode($manutenzione);

    // Inserisci nel log storico (con azione 'completata')
    $azione = 'completata';
    $note_azione = '';

    $stmt4 = $conn->prepare("INSERT INTO storico_manutenzioni (id_manutenzione, azione, utente, dati_precedenti, dati_nuovi, note_azione) VALUES (?, ?, ?, ?, ?, ?)");
    $dati_nuovi = null; // perchè stiamo cancellando la manutenzione
    $stmt4->bind_param("isssss", $id, $azione, $utente, $dati_precedenti, $dati_nuovi, $note_azione);
    if (!$stmt4->execute()) {
        die("Errore nell'inserimento storico manutenzioni: " . $stmt4->error);
    }
    $stmt4->close();

    // Ora elimina la manutenzione
    $stmt_delete = $conn->prepare("DELETE FROM manutenzioni WHERE id = ?");
    $stmt_delete->bind_param("i", $id);
    if (!$stmt_delete->execute()) {
        die("Errore nell'eliminazione manutenzione: " . $stmt_delete->error);
    }
    $stmt_delete->close();

    header("Location: visualizza_calendario.php?msg=Manutenzione completata ed eliminata");
    exit;
} else {
    die("Richiesta non valida.");
}
?>
