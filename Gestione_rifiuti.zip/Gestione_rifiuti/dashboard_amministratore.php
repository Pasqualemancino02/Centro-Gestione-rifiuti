<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'amministratore') {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Dashboard Amministratore</title>
    <link rel="stylesheet" href="css/style.css" />
</head>

<style>
  .boxes-wrapper {
    display: flex !important;
    gap: 20px !important;
    justify-content: center !important;
    flex-wrap: wrap !important;
  }
  .box {
    width: 280px !important;
    background-color: #e6f0e8 !important;
    border-radius: 10px !important;
    padding: 20px !important;
    text-align: center !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
  }
</style>

<body class="dashboard-amministratore">
    <header class="welcome-header">
        Benvenuto Amministratore: <?php echo htmlspecialchars($_SESSION['email']); ?>
    </header>
    
    <!-- Pulsante Logout -->
    <div class="logout-button">
        <a href="logout.php" title="Logout">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#2d6a4f" viewBox="0 0 24 24">
                <path d="M10 17v-2h4v-2h-4v-2h4V9h-4V7l-5 5 5 5zm4 4H6V3h8v2h2V3a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-2h-2v2z"/>
            </svg>
        </a>
    </div>

    <!-- Pulsante Ritorna alla home -->
    <div class="back-home">
        <a href="homepage.html" title="Ritorna alla home">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#2d6a4f" viewBox="0 0 24 24">
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
            </svg>
        </a>
    </div>

    <div class="container">
        <p>Qui puoi vedere e gestire le tue attività operative.</p>

        <div class="boxes-wrapper">
            <!--box per i report alle autorità --> 
            <div class="box">
                <h2>Genera report per le autorità</h2>
                <p>Accedi agli strumenti per creare report dettagliati sulle attività e i conferimenti.</p>
                <a href="genera_report.php" class="btn">Vai ai report</a>
            </div>

            <!--box per la turnazione impianti e manutenzione -->
            <div class="box">
                <h2>Pianifica turnazione impianti e manutenzione</h2>
                <p>Organizza i turni e programma la manutenzione degli impianti per garantire efficienza.</p>
                <a href="pianificazione_impianti.php" class="btn">Pianifica ora</a>
            </div>

            <!--box per visualizzare i dipendenti -->
            <div class="box">
                <h2>Visualizza dipendenti</h2>
                <p>Gestisci e consulta i dettagli dei dipendenti registrati nel sistema.</p>
                <a href="lista_dipendenti.php" class="btn">Visualizza dipendenti</a>
            </div>

            <!-- nuovo box per gestire impianti -->
            <div class="box">
                <h2>Gestione Impianti</h2>
                <p>Inserisci, modifica o elimina gli impianti registrati nel sistema.</p>
                <a href="gestione_impianti.php" class="btn">Vai alla gestione impianti</a>
            </div>
        </div>
    </div>
</body>
</html>
