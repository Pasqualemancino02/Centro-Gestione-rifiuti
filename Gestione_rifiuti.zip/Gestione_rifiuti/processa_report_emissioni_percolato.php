<?php
session_start();

// Controlla se utente è amministratore
if (!isset($_SESSION['id']) || $_SESSION['ruolo'] !== 'amministratore') {
    header("Location: login.html");
    exit();
}

include 'db_connection.php';

// Inizializzo le variabili date per mantenere il valore nel form
$data_inizio = isset($_GET['data_inizio']) ? $_GET['data_inizio'] : '';
$data_fine = isset($_GET['data_fine']) ? $_GET['data_fine'] : '';

// Preparo la query base
$sql = "
    SELECT m.ID_monitoraggio, m.conferimento_id, c.tipo, c.data AS data_conferimento, 
           m.data_rilevazione, m.co2_emessa, m.percolato_rilevato, m.note
    FROM monitoraggio_emissioni_percolato m
    JOIN conferimenti c ON m.conferimento_id = c.ID_conferimento
";

// Aggiungo filtro se date valide
$params = [];
if ($data_inizio && $data_fine) {
    $sql .= " WHERE m.data_rilevazione BETWEEN ? AND ?";
    $params[] = $data_inizio;
    $params[] = $data_fine;
}

$sql .= " ORDER BY m.data_rilevazione DESC";

$stmt = $conn->prepare($sql);

if ($params) {
    $stmt->bind_param("ss", ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Genera Report Emissioni e Percolato</title>
    <link rel="stylesheet" href="css/style.css" />
    <style>
        .table-scroll-wrapper {
            max-width: 100%;
            overflow-x: auto;
        }
        .report-table th,
        .report-table td {
            min-width: 120px;
            padding: 8px;
            border: 1px solid #ccc;
            text-align: left;
        }
        .report-table {
            border-collapse: collapse;
            width: 100%;
        }
        #download-pdf-btn {
            margin-bottom: 15px;
            padding: 8px 16px;
            background-color: #16a085;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-size: 14px;
        }
        #download-pdf-btn:hover {
            background-color: #13856e;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            margin-right: 10px;
            font-weight: bold;
        }
        input[type="date"] {
            margin-right: 15px;
            padding: 4px 6px;
        }
        input[type="submit"] {
            padding: 6px 14px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        input[type="submit"]:hover {
            background-color: #1c5980;
        }
    </style>
</head>
<body class="dashboard-amministratore">
    <div class="back-dashboard">
        <a href="dashboard_amministratore.php" title="Torna alla Dashboard">← Torna alla Dashboard</a>
    </div>

    <div class="container report_emissioni_percolato">
        <h2>Genera Report Emissioni e Percolato</h2>

        <form method="GET" action="genera_report_emissioni_percolato.php">
            <label for="data_inizio">Data Inizio:</label>
            <input type="date" id="data_inizio" name="data_inizio" value="<?php echo htmlspecialchars($data_inizio); ?>" required />

            <label for="data_fine">Data Fine:</label>
            <input type="date" id="data_fine" name="data_fine" value="<?php echo htmlspecialchars($data_fine); ?>" required />

            <input type="submit" value="Filtra" />
        </form>

        <?php if ($result && $result->num_rows > 0): ?>
            <button id="download-pdf-btn">Scarica PDF</button>

            <div class="table-scroll-wrapper">
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>ID Monitoraggio</th>
                            <th>ID Conferimento</th>
                            <th>Tipo Conferimento</th>
                            <th>Data Conferimento</th>
                            <th>Data Rilevazione</th>
                            <th>CO₂ Emessa (kg)</th>
                            <th>Percolato Rilevato (litri)</th>
                            <th>Note</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['ID_monitoraggio']); ?></td>
                            <td><?php echo htmlspecialchars($row['conferimento_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                            <td><?php echo htmlspecialchars($row['data_conferimento']); ?></td>
                            <td><?php echo htmlspecialchars($row['data_rilevazione']); ?></td>
                            <td><?php echo htmlspecialchars($row['co2_emessa']); ?></td>
                            <td><?php echo htmlspecialchars($row['percolato_rilevato']); ?></td>
                            <td><?php echo htmlspecialchars($row['note']); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>
            <?php if ($data_inizio && $data_fine): ?>
                <p>Nessun dato trovato nel periodo selezionato.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- jsPDF e jsPDF AutoTable da CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>

    <script>
        document.getElementById('download-pdf-btn')?.addEventListener('click', () => {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            doc.setFontSize(14);
            doc.text("Report Emissioni e Percolato", 14, 15);

            doc.autoTable({
                html: '.report-table',
                startY: 25,
                styles: { fontSize: 8 },
                headStyles: { fillColor: [22, 160, 133] },
                margin: { left: 14, right: 14 }
            });

            doc.save('report_emissioni_percolato_<?php echo htmlspecialchars($data_inizio . "_to_" . $data_fine); ?>.pdf');
        });
    </script>
</body>
</html>
