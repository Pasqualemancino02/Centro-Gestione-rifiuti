<?php 
$conn = new mysqli("localhost", "root", "", "gestione rifiuti");

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$email = $_POST['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Reset Password - Centro Gestione Rifiuti</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    
    <!-- Pulsante Ritorna alla home -->
    <div class="back-home">
      <a href="homepage.html" title="Ritorna alla home">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#2d6a4f" viewBox="0 0 24 24">
          <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
        </svg>
      </a>
    </div>

    <div class="container">

        <img src="img/logo.png" alt="Logo Centro Gestione Rifiuti" class="logo" />
        <h1>Reset Password</h1>
        <?php
        if (!empty($email)) {
            $stmt = $conn->prepare("SELECT id FROM utenti WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                echo '
                <form method="POST" action="update_password.php">
                    <input type="hidden" name="email" value="' . htmlspecialchars($email) . '">
                    <input type="password" name="new_password" placeholder="Nuova password" required />
                    <input type="submit" value="Aggiorna password" />
                </form>';
            } else {
                echo "<p>Email non trovata.</p>
                <div class='links'><a href='forgot_password.php'>Riprova</a></div>";
            }
        } else {
            // Form iniziale per richiedere email
            echo '
            <form action="reset_password.php" method="POST">
                <input type="email" name="email" placeholder="Inserisci la tua email" required />
                <input type="submit" value="Invia" />
            </form>';
        }
        ?>
        <div class="links">
            <a href="login.html">Torna al login</a>
        </div>
    </div>
</body>
</html>
