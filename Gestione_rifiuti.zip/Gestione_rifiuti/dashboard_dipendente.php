<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'dipendente') {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Dipendente</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body class="dashboard-dipendente">
    <header class="welcome-header">
        Benvenuto Dipendente: <?php echo htmlspecialchars($_SESSION['email']); ?>
    </header>
    
    <!-- Pulsante Logout -->
    <div class="logout-button">
        <a href="logout.php" title="Logout">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#2d6a4f" viewBox="0 0 24 24">
                <path d="M10 17v-2h4v-2h-4v-2h4V9h-4V7l-5 5 5 5zm4 4H6V3h8v2h2V3a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-2h-2v2z"/>
            </svg>
        </a>
    </div>

    <!-- Pulsante Ritorna alla home -->
    <div class="back-home">
        <a href="homepage.html" title="Ritorna alla home">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#2d6a4f" viewBox="0 0 24 24">
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
            </svg>
        </a>
    </div>

    <div class="container">
        <p>Qui puoi vedere e gestire le tue attività operative.</p>

        <div class="boxes-wrapper">
            <div class="box">
                <h2>Inserisci nuovo conferimento</h2>
                <!-- Icona cestino SVG -->
                <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#2d6a4f" viewBox="0 0 24 24" style="margin-bottom: 15px;">
                    <path d="M3 6h18v2H3V6zm2 3h14l-1.5 12.5a1 1 0 0 1-1 .5h-7a1 1 0 0 1-1-.5L5 9zm5-7h4v2h-4V2z"/>
                </svg>
                <p>Qui puoi inserire i tuoi nuovi conferimenti.</p>
                <a class="btn" href="inserisci_conferimento.php">Vai</a>
            </div>

            <div class="box">
                <h2>Visualizza i miei conferimenti</h2>
                <!-- Icona lista SVG -->
                <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#2d6a4f" viewBox="0 0 24 24" style="margin-bottom: 15px;">
                    <path d="M4 6h16v2H4V6zm0 5h16v2H4v-2zm0 5h16v2H4v-2z"/>
                </svg>
                <p>Controlla e gestisci i conferimenti effettuati.</p>
                <a class="btn" href="visualizza_miei_conferimenti.php">Vai</a>
            </div>

            <div class="box">
                <h2>Emissioni e Percolato</h2>
                <!-- Icona rappresentativa (foglia o ambiente) -->
                <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#2d6a4f" viewBox="0 0 24 24" style="margin-bottom: 15px;">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 3.38 2.45 6.16 5.73 6.73V22h2v-6.27C16.55 15.16 19 12.38 19 9c0-3.87-3.13-7-7-7zM7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 2.08-1.27 3.87-3.14 4.65L12 19.5l-1.86-5.85C8.27 12.87 7 11.08 7 9z"/>
                </svg>
                <p>Inserisci e visualizza i dati di emissioni CO2 e percolato per i tuoi conferimenti.</p>
                <a class="btn" href="emissioni_percolato.php">Vai</a>
            </div>
        </div>
    </div>
</body>
</html>
