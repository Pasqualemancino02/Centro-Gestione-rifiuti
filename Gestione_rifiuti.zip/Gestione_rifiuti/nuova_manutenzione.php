<?php
session_start();

require_once 'db_connection.php';

$success = '';
$error = '';

// Recupera impianti attivi per il select
$impianti = [];
$sql = "SELECT ID_impianto, nome FROM impianti WHERE stato = 'attivo' ORDER BY nome";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $impianti[] = $row;
    }
} else {
    $error = "Errore nel recuperare gli impianti.";
}

// Variabili per mantenere i dati nel form in caso di errore
$id_impianto = '';
$data_manutenzione = '';
$tipo_intervento = '';
$note = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_impianto = intval($_POST['id_impianto']);
    $data_manutenzione = $_POST['data_manutenzione'];
    $tipo_intervento = trim($_POST['tipo_intervento']);
    $note = trim($_POST['note']);

    if (!$id_impianto || !$data_manutenzione || !$tipo_intervento) {
        $error = "Compila tutti i campi obbligatori.";
    } else {
        // Inserimento solo nella tabella manutenzioni, senza storico
        $stmt = $conn->prepare("INSERT INTO manutenzioni (id_impianto, data_manutenzione, tipo_intervento, note) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $id_impianto, $data_manutenzione, $tipo_intervento, $note);

        if ($stmt->execute()) {
            $success = "Manutenzione inserita correttamente.";
            // Reset valori form dopo inserimento
            $id_impianto = '';
            $data_manutenzione = '';
            $tipo_intervento = '';
            $note = '';
        } else {
            $error = "Errore durante l'inserimento: " . $stmt->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Nuova Manutenzione</title>
    <link rel="stylesheet" href="css/style.css" />
    <style>
      .form-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 15px;
      }
      .form-group label {
        margin-bottom: 5px;
        font-weight: 600;
      }
      select, input[type="date"], input[type="text"], textarea {
        padding: 8px;
        font-size: 1rem;
        border: 1px solid #ccc;
        border-radius: 4px;
        width: 100%;
        box-sizing: border-box;
      }
      .message {
        margin-bottom: 15px;
        font-weight: 600;
      }
      .success {
        color: green;
      }
      .error {
        color: red;
      }
    </style>
</head>
<body class="dashboard-amministratore">
    <div class="back-dashboard">
       <a href="pianificazione_impianti.php" title="Torna a Gestione Turnazioni">← Torna indietro</a>
    </div>

  <div class="container" style="max-width: 500px;">
    <h1>Nuova Manutenzione</h1>

    <?php if ($success): ?>
      <div class="message success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="message error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="post" action="">
      <div class="form-group">
        <label for="id_impianto">Impianto *</label>
        <select id="id_impianto" name="id_impianto" required>
          <option value="">-- Seleziona Impianto --</option>
          <?php foreach ($impianti as $impianto): ?>
            <option value="<?php echo $impianto['ID_impianto']; ?>" <?php echo ($impianto['ID_impianto'] == $id_impianto) ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars($impianto['nome']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label for="data_manutenzione">Data Manutenzione *</label>
        <input type="date" id="data_manutenzione" name="data_manutenzione" required value="<?php echo htmlspecialchars($data_manutenzione); ?>" />
      </div>

      <div class="form-group">
        <label for="tipo_intervento">Tipo Intervento *</label>
        <input type="text" id="tipo_intervento" name="tipo_intervento" required maxlength="255" value="<?php echo htmlspecialchars($tipo_intervento); ?>" />
      </div>

      <div class="form-group">
        <label for="note">Note</label>
        <textarea id="note" name="note" rows="4"><?php echo htmlspecialchars($note); ?></textarea>
      </div>

      <button type="submit" class="btn btn-large" style="margin-top: 20px;">Salva Manutenzione</button>
    </form>
  </div>
</body>
</html>

