<?php
session_start();

// Controlla se l'utente è loggato e ha ruolo dipendente
if (!isset($_SESSION['id']) || $_SESSION['ruolo'] !== 'dipendente') {
    header("Location: login.html");
    exit();
}

include 'db_connection.php'; // Connessione al database

$dipendente_id = $_SESSION['id'];

// Prepara la query per prendere i conferimenti associati al dipendente
$sql = "
    SELECT c.*
    FROM conferimenti c
    WHERE c.dipendente_id = ?
      AND NOT EXISTS (
          SELECT 1
          FROM monitoraggio_emissioni_percolato m
          WHERE m.conferimento_id = c.ID_conferimento
      )
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Errore nella preparazione della query: " . $conn->error);
}

$stmt->bind_param("i", $dipendente_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Emissioni e Percolato</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body class="dashboard-dipendente">
    

    <!--pulsante per tornare alla dashboard dipendente-->
    <div class="back-dashboard">
        <a href="dashboard_dipendente.php" title="Torna alla Dashboard">← Dashboard</a>
    </div>

    <div class="container emissioni_percolato">
        <h2>I tuoi conferimenti - Inserisci Emissioni e Percolato</h2>

        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <div class="box">
                    <h3>Conferimento #<?php echo htmlspecialchars($row['ID_conferimento']); ?></h3>
                    <p><strong>Tipo:</strong> <?php echo htmlspecialchars($row['tipo']); ?></p>
                    <p><strong>Data:</strong> <?php echo htmlspecialchars($row['data']); ?></p>

                    <form action="salva_emissioni_percolato.php" method="POST">
                        <input type="hidden" name="conferimento_id" value="<?php echo htmlspecialchars($row['ID_conferimento']); ?>">

                        <label for="data_rilevazione_<?php echo $row['ID_conferimento']; ?>">Data rilevazione:</label><br>
                        <input type="date" id="data_rilevazione_<?php echo $row['ID_conferimento']; ?>" name="data_rilevazione" required><br><br>

                        <label for="co2_emessa_<?php echo $row['ID_conferimento']; ?>">CO₂ emessa (kg):</label><br>
                        <input type="number" id="co2_emessa_<?php echo $row['ID_conferimento']; ?>" name="co2_emessa" step="0.001" min="0" required><br><br>

                        <label for="percolato_rilevato_<?php echo $row['ID_conferimento']; ?>">Percolato rilevato (litri):</label><br>
                        <input type="number" id="percolato_rilevato_<?php echo $row['ID_conferimento']; ?>" name="percolato_rilevato" step="0.001" min="0" required><br><br>

                        <label for="note_<?php echo $row['ID_conferimento']; ?>">Note (opzionale):</label><br>
                        <textarea id="note_<?php echo $row['ID_conferimento']; ?>" name="note" rows="2" cols="30" placeholder="Eventuali osservazioni..."></textarea><br><br>

                        <button type="submit" class="btn">Salva Dati</button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Non ci sono conferimenti in attesa di monitoraggio.</p>
        <?php endif; ?>

    </div>
</body>
</html>


