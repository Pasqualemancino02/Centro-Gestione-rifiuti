<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'amministratore') {
    header("Location: login.html");
    exit();
}

// Configurazione DB (modifica con i tuoi dati)
$host = "localhost";
$user = "root";        // utente di default XAMPP
$password = "";        // password vuota di default XAMPP
$dbname = "gestione rifiuti";   // nome del tuo database, senza spazi

// Connessione al DB
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Query per prendere solo i dipendenti
$sql = "SELECT id, email, nome, cognome, data_registrazione FROM utenti WHERE ruolo = 'dipendente' ORDER BY cognome, nome";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Lista Dipendenti</title>
    <link rel="stylesheet" href="css/style.css" />
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            background: #e6f0e8;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.15);
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px 15px;
            text-align: left;
        }
        th {
            background-color: #2d6a4f;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #d9ead3;
        }
        /* Contenitore centrale per titolo e tabella */
        .container {
            width: 90%;
            max-width: 1000px;
            margin: 40px auto 0 auto; /* margine superiore e centratura */
        }
        .container h1 {
            text-align: center;
            color: #2d6a4f;
            margin-bottom: 20px;
        }
        /* Pulsante torna alla dashboard in alto a sinistra */
        .back-dashboard {
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1100;
        }
        .back-dashboard a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(45, 106, 79, 0.9);
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            box-shadow: 0 1px 4px rgba(0,0,0,0.3);
            transition: background-color 0.3s;
            font-size: 14px;
        }
        .back-dashboard a:hover {
            background-color: #1b4332;
        }
    </style>
</head>
<body>

    <div class="back-dashboard">
        <a href="dashboard_amministratore.php" title="Torna alla Dashboard">← Dashboard</a>
    </div>

    <div class="container">
        <h1>Lista Dipendenti</h1>

        <?php if ($result && $result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Nome</th>
                        <th>Cognome</th>
                        <th>Data Registrazione</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['nome']) ?></td>
                        <td><?= htmlspecialchars($row['cognome']) ?></td>
                        <td><?= htmlspecialchars($row['data_registrazione']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align:center; color:#2d6a4f;">Nessun dipendente trovato.</p>
        <?php endif; ?>
    </div>

</body>
</html>

<?php
$conn->close();
?>
