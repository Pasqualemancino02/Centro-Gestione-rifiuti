<?php
$conn = new mysqli("localhost", "root", "", "gestione rifiuti");
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$ruolo = $_POST['ruolo'] ?? '';
$nome = $_POST['nome'] ?? '';
$cognome = $_POST['cognome'] ?? '';

$message = ''; // messaggio da mostrare

// Controllo se email già esiste
$sql_check = "SELECT * FROM utenti WHERE email = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("s", $email);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    $message = "Errore: Email già registrata.";
} else {
    $hash_password = password_hash($password, PASSWORD_DEFAULT);
    $sql_insert = "INSERT INTO utenti (nome, cognome, email, password, ruolo) VALUES (?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("sssss", $nome, $cognome, $email, $hash_password, $ruolo);

    if ($stmt_insert->execute()) {
        $message = "Registrazione avvenuta con successo!";
        $success = true;
    } else {
        $message = "Errore durante la registrazione: " . $conn->error;
        $success = false;
    }
    $stmt_insert->close();
}

$stmt_check->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8" />
  <title>Registrazione - Centro Gestione Rifiuti</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <div class="back-home">
    <a href="homepage.html" title="Ritorna alla home">
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#2d6a4f" viewBox="0 0 24 24">
        <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
      </svg>
    </a>
  </div>

  <div class="container">
    <img src="img/logo.png" alt="Logo Centro Gestione Rifiuti" class="logo" />
    <h1>Registrazione</h1>

    <p><?= htmlspecialchars($message) ?></p>

    <?php if (!isset($success) || !$success): ?>
      <a href="registrazione.html">Torna alla registrazione</a>
    <?php else: ?>
      <a href="login.html">Vai al login</a>
    <?php endif; ?>
  </div>
</body>
</html>
