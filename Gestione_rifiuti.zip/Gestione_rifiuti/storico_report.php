<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'amministratore') {
    header("Location: login.html");
    exit();
}

require_once("db_connection.php");

$sql = "SELECT report.*, utenti.email AS email_amministratore 
        FROM report 
        JOIN utenti ON report.utente_id = utenti.id 
        ORDER BY data_generazione DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Storico Report</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="dashboard-amministratore">

<div class="back-dashboard">
  <a href="genera_report.php">&larr; Torna indietro</a>
</div>

<div class="report-container">
    <h2>Storico Report Generati</h2>

    <?php if ($result->num_rows > 0): ?>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Data Generazione</th>
                    <th>Generato da</th>
                    <th>Intervallo</th>
                    <!-- <th>File PDF</th> --> <!-- Rimosso -->
                    <th>Note</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['data_generazione']) ?></td>
                    <td><?= htmlspecialchars($row['email_amministratore']) ?></td>
                    <td><?= htmlspecialchars($row['filtro_data_inizio']) ?> - <?= htmlspecialchars($row['filtro_data_fine']) ?></td>
                    <!--
                    <td>
                        <?php
                        // $pdf_path = "report_pdf/" . $row['percorso_file'];
                        // if (file_exists($pdf_path)):
                        ?>
                            <a href="<?= $pdf_path ?>" target="_blank">Apri</a>
                        <?php
                        // else:
                        ?>
                            <em>Non disponibile</em>
                        <?php
                        // endif;
                        ?>
                    </td>
                    --> <!-- Rimosso -->
                    <td><?= htmlspecialchars($row['note']) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nessun report presente.</p>
    <?php endif; ?>

</div>

</body>
</html>

<?php
$conn->close();
?>
