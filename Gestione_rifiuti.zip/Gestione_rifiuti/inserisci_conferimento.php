<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'dipendente') {
    header("Location: login.html");
    exit();
}

// Connessione per prendere gli impianti (per la select)
$conn = new mysqli("localhost", "root", "", "gestione rifiuti");
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$sql_impianti = "SELECT ID_impianto, nome FROM impianti WHERE stato = 'attivo'";
$result_impianti = $conn->query($sql_impianti);
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Inserisci Conferimento - Centro Gestione Rifiuti</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <div class="container">
        <h1>Inserisci Nuovo Conferimento</h1>
        <form action="processa_conferimento.php" method="POST">
            <label for="tipo">Tipo conferimento:</label><br>
            <select id="tipo" name="tipo" required>
                <option value="">-- Seleziona tipo --</option>
                <option value="Plastica">Plastica</option>
                <option value="Vetro">Vetro</option>
                <option value="Carta">Carta</option>
                <option value="Organico">Organico</option>
                <option value="Indifferenziato">Indifferenziato</option>
            </select><br><br>

            <label for="data">Data conferimento:</label><br>
            <input type="date" id="data" name="data" required><br><br>

            <label for="peso">Peso (kg):</label><br>
            <input type="number" id="peso" name="peso" step="0.01" min="0" required><br><br>

            <label for="stato">Stato:</label><br>
            <select id="stato" name="stato" required>
                <option value="in attesa">In attesa</option>
                <option value="processato">Processato</option>
                <option value="completato">Completato</option>
            </select><br><br>

            <label for="impianto">Impianto:</label><br>
            <select id="impianto" name="impianto_id" required>
                <option value="">-- Seleziona Impianto --</option>
                <?php
                if ($result_impianti->num_rows > 0) {
                    while ($row = $result_impianti->fetch_assoc()) {
                        echo '<option value="' . $row['ID_impianto'] . '">' . htmlspecialchars($row['nome']) . '</option>';
                    }
                }
                ?>
            </select><br><br>

            <label for="provenienza">Provenienza:</label><br>
            <input type="text" id="provenienza" name="provenienza" required><br><br>

            <label for="tipo_smaltimento">Tipo smaltimento:</label><br>
            <select id="tipo_smaltimento" name="tipo_smaltimento" required>
                <option value="">-- Seleziona tipo smaltimento --</option>
                <option value="Riciclaggio">Riciclaggio</option>
                <option value="Discarica">Discarica</option>
                <option value="Incenerimento">Incenerimento</option>
            </select><br><br>

            <label for="pericolosita">Pericolosità:</label><br>
            <select id="pericolosita" name="pericolosita" required>
                <option value="">-- Seleziona pericolosità --</option>
                <option value="no">NO</option>
                <option value="si">SI</option>
            </select><br><br>

            <input type="submit" value="Inserisci Conferimento">
        </form>
        <br>
        <a href="dashboard_dipendente.php">Torna alla Dashboard</a>
    </div>
</body>
</html>

<?php
$conn->close();
?>

