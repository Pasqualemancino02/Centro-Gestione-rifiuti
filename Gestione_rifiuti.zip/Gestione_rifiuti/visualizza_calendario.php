<?php
session_start();
require_once 'db_connection.php';

$error = '';
$manutenzioni = [];

// Filtri base
$whereClauses = [];
$params = [];
$types = '';

if (!empty($_GET['data_inizio'])) {
    $whereClauses[] = 'data_manutenzione >= ?';
    $params[] = $_GET['data_inizio'];
    $types .= 's';
}
if (!empty($_GET['data_fine'])) {
    $whereClauses[] = 'data_manutenzione <= ?';
    $params[] = $_GET['data_fine'];
    $types .= 's';
}

$whereSql = '';
if (count($whereClauses) > 0) {
    $whereSql = ' WHERE ' . implode(' AND ', $whereClauses);
}

// Query con join impianti per nome
$sql = "SELECT m.id, i.nome AS impianto, m.data_manutenzione, m.tipo_intervento, m.note 
        FROM manutenzioni m
        JOIN impianti i ON m.id_impianto = i.ID_impianto
        $whereSql
        ORDER BY m.data_manutenzione DESC";

$stmt = $conn->prepare($sql);

if ($stmt) {
    if ($types) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $manutenzioni[] = $row;
    }
    $stmt->close();
} else {
    $error = "Errore nella preparazione della query.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Visualizza Manutenzioni</title>
    <link rel="stylesheet" href="css/style.css" />
    <style>
      /* Pulsanti azioni */
      form.inline-form {
        display: inline-block;
        margin: 0;
        padding: 0;
      }
      input[type="submit"].btn-completa {
        padding: 4px 8px;
        font-size: 14px;
        cursor: pointer;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 3px;
      }
      input[type="submit"].btn-elimina {
        padding: 4px 8px;
        font-size: 14px;
        cursor: pointer;
        background-color: #f44336;
        color: white;
        border: none;
        border-radius: 3px;
        margin-left: 5px;
      }
    </style>
</head>
<body class="dashboard-amministratore">

<div class="back-dashboard">
   <a href="pianificazione_impianti.php" title="Torna a Gestione Turnazioni">← Torna indietro</a>
</div>

<div class="report-container">
    <h1>Manutenzioni Pianificate</h1>

    <?php if ($error): ?>
      <div style="color:red; margin-bottom: 15px;"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="get" action="" style="margin-bottom: 20px;">
      <label for="data_inizio">Data inizio:</label>
      <input type="date" id="data_inizio" name="data_inizio" value="<?php echo isset($_GET['data_inizio']) ? htmlspecialchars($_GET['data_inizio']) : ''; ?>" />

      <label for="data_fine">Data fine:</label>
      <input type="date" id="data_fine" name="data_fine" value="<?php echo isset($_GET['data_fine']) ? htmlspecialchars($_GET['data_fine']) : ''; ?>" />

      <button type="submit" class="btn" style="margin-left: 10px;">Filtra</button>
      <a href="visualizza_calendario.php" class="btn reset" style="margin-left: 10px;">Reset</a>
    </form>

    <?php if (count($manutenzioni) === 0): ?>
      <p>Nessuna manutenzione trovata.</p>
    <?php else: ?>
      <div style="overflow-x: auto; width: 100%; display: block; white-space: nowrap; padding-bottom: 10px;">
        <table style="border-collapse: collapse; min-width: 900px; width: 100%;">
          <thead>
            <tr style="background-color: #f2f2f2;">
              <th style="padding: 10px; border: 1px solid #ccc;">ID</th>
              <th style="padding: 10px; border: 1px solid #ccc;">Impianto</th>
              <th style="padding: 10px; border: 1px solid #ccc;">Data Manutenzione</th>
              <th style="padding: 10px; border: 1px solid #ccc;">Tipo Intervento</th>
              <th style="padding: 10px; border: 1px solid #ccc;">Note</th>
              <th style="padding: 10px; border: 1px solid #ccc;">Azioni</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($manutenzioni as $m): ?>
            <tr>
              <td style="text-align:center; padding: 8px; border: 1px solid #ccc;"><?php echo htmlspecialchars($m['id']); ?></td>
              <td style="padding: 8px; border: 1px solid #ccc;"><?php echo htmlspecialchars($m['impianto']); ?></td>
              <td style="text-align:center; padding: 8px; border: 1px solid #ccc;"><?php echo htmlspecialchars($m['data_manutenzione']); ?></td>
              <td style="padding: 8px; border: 1px solid #ccc;"><?php echo htmlspecialchars($m['tipo_intervento']); ?></td>
              <td style="padding: 8px; border: 1px solid #ccc;"><?php echo htmlspecialchars($m['note']); ?></td>
              <td style="text-align:center; padding: 8px; border: 1px solid #ccc;">
                <form action="completa_manutenzione.php" method="post" class="inline-form" onsubmit="return confirm('Sei sicuro di voler segnare questa manutenzione come completata?');">
                  <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                  <input type="submit" value="✓ Completata" class="btn-completa">
                </form>
                <form action="elimina_manutenzione.php" method="post" class="inline-form" onsubmit="return confirm('Sei sicuro di voler eliminare questa manutenzione?');">
                  <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                  <input type="submit" value="✖ Elimina" class="btn-elimina">
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
</div>

</body>
</html>
