<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'dipendente') {
    header("Location: login.html");
    exit();
}

require_once 'db_connection.php';

$email = $_SESSION['email'];

// Recupera ID utente
$stmt = $conn->prepare("SELECT ID FROM utenti WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    die("Utente non trovato.");
}
$row = $result->fetch_assoc();
$dipendente_id = $row['ID'];

// Recupera conferimenti
$stmt = $conn->prepare("
    SELECT 
        c.ID_conferimento, c.tipo, c.data, c.peso, c.stato,
        c.provenienza, c.tipo_smaltimento, c.pericolosita,
        i.nome AS nome_impianto
    FROM conferimenti c
    JOIN impianti i ON c.impianto_id = i.ID_impianto
    WHERE c.dipendente_id = ?
    ORDER BY c.data DESC
");
$stmt->bind_param("i", $dipendente_id);
$stmt->execute();
$conferimenti = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8" />
  <title>I miei conferimenti</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    body {
      background-color: #f0f4f3;
      font-family: Arial, sans-serif;
    }

    .main-section {
      max-width: 1200px;
      margin: 40px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
    }

    h1 {
      color: #2d6a4f;
      margin-bottom: 20px;
      text-align: center;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 10px;
      text-align: center;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #2d6a4f;
      color: white;
    }

    tr:hover {
      background-color: #f1f1f1;
    }

    .btn {
      display: inline-block;
      margin-top: 10px;
      background-color: #2d6a4f;
      color: white;
      padding: 8px 16px;
      border-radius: 6px;
      text-decoration: none;
      transition: background-color 0.3s;
    }

    .btn:hover {
      background-color: #1b4332;
    }

    .btn-danger {
      background-color: #b02a37;
    }

    .btn-danger:hover {
      background-color: #7c1a25;
    }

    p {
      text-align: center;
      font-size: 16px;
      color: #555;
    }
  </style>
</head>
<body>
  

<div class="main-section">
  <h1>I miei conferimenti</h1>

  <?php if ($conferimenti->num_rows === 0): ?>
    <p>Non hai ancora inserito conferimenti.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Tipo</th>
          <th>Data</th>
          <th>Peso (kg)</th>
          <th>Stato</th>
          <th>Provenienza</th>
          <th>Tipo smaltimento</th>
          <th>Pericolosità</th>
          <th>Impianto</th>
          <th>Azioni</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $conferimenti->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['ID_conferimento']) ?></td>
            <td><?= htmlspecialchars($row['tipo']) ?></td>
            <td><?= htmlspecialchars($row['data']) ?></td>
            <td><?= htmlspecialchars($row['peso']) ?></td>
            <td><?= htmlspecialchars($row['stato']) ?></td>
            <td><?= htmlspecialchars($row['provenienza']) ?></td>
            <td><?= htmlspecialchars($row['tipo_smaltimento']) ?></td>
            <td><?= htmlspecialchars(ucfirst($row['pericolosita'])) ?></td>
            <td><?= htmlspecialchars($row['nome_impianto']) ?></td>
            <td style="text-align:center;">
              <a href="modifica_conferimento.php?id=<?= $row['ID_conferimento'] ?>" class="btn">Modifica</a><br>
              <a href="conferma_eliminazione_conf.php?id=<?= $row['ID_conferimento'] ?>" class="btn btn-danger">Elimina</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php endif; ?>

  <div style="text-align: center;">
    <a class="btn" href="dashboard_dipendente.php">⬅ Torna alla dashboard</a>
  </div>
</div>

</body>
</html>


