<?php
session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    // Elimina la manutenzione dalla tabella manutenzioni
    $stmt = $conn->prepare("DELETE FROM manutenzioni WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        // Redirect alla pagina del calendario con messaggio di successo
        header("Location: visualizza_calendario.php?msg=Manutenzione eliminata correttamente");
        exit;
    } else {
        $error = "Errore durante l'eliminazione: " . $stmt->error;
        $stmt->close();
        $conn->close();
    }
} else {
    $error = "ID manutenzione non valido.";
}

?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Elimina Manutenzione</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body class="dashboard-amministratore">
    <div class="back-dashboard">
       <a href="visualizza_calendario.php">← Torna al calendario</a>
    </div>

    <div class="container" style="max-width: 500px; margin-top: 20px;">
        <?php if (!empty($error)): ?>
            <div style="color: red; font-weight: bold;"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
