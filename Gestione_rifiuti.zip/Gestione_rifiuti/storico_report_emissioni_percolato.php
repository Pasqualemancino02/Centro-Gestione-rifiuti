<?php
session_start();

// Controlla se utente è amministratore
if (!isset($_SESSION['id']) || $_SESSION['ruolo'] !== 'amministratore') {
    header("Location: login.html");
    exit();
}

include 'db_connection.php';

// Prendi la data dal GET, se presente
$data_inizio = isset($_GET['data_inizio']) ? $_GET['data_inizio'] : '';

// Query con filtro data_inizio solo se impostata
$sql = "
    SELECT m.ID_monitoraggio, m.conferimento_id, c.tipo, c.data AS data_conferimento, 
           m.data_rilevazione, m.co2_emessa, m.percolato_rilevato, m.note
    FROM monitoraggio_emissioni_percolato m
    JOIN conferimenti c ON m.conferimento_id = c.ID_conferimento
";

if ($data_inizio) {
    $sql .= " WHERE m.data_rilevazione >= ?";
}

$sql .= " ORDER BY m.data_rilevazione DESC";

// Prepariamo la query con bind_param per sicurezza
if ($stmt = $conn->prepare($sql)) {
    if ($data_inizio) {
        $stmt->bind_param("s", $data_inizio);
    }
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    die("Errore nella query: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Report Emissioni e Percolato</title>
    <link rel="stylesheet" href="css/style.css" />
    <style>
        .table-scroll-wrapper {
            max-width: 100%;
            overflow-x: auto;
        }
        .report-table th,
        .report-table td {
            min-width: 120px;
            padding: 8px;
            border: 1px solid #ccc;
            text-align: left;
        }
        .report-table {
            border-collapse: collapse;
            width: 100%;
        }
        #download-pdf-btn {
            margin-bottom: 15px;
            padding: 8px 16px;
            background-color: #16a085;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-size: 14px;
        }
        #download-pdf-btn:hover {
            background-color: #13856e;
        }
        form.filtro-date label {
            font-weight: bold;
            margin-right: 5px;
        }
        form.filtro-date input[type="date"] {
            padding: 4px 6px;
            margin-right: 15px;
        }
        form.filtro-date button {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            color: white;
            cursor: pointer;
        }
        form.filtro-date button.filtra {
            background-color: #2980b9;
        }
        form.filtro-date button.filtra:hover {
            background-color: #2471a3;
        }
        form.filtro-date button.reset {
            background-color: #7f8c8d;
            margin-left: 10px;
        }
        form.filtro-date button.reset:hover {
            background-color: #6c7a89;
        }
    </style>
</head>
<body class="dashboard-amministratore">
    <div class="back-dashboard">
        <a href="genera_report.php" title="Torna a Genera Report">← Torna a Genera Report</a>
    </div>

    <div class="container report_emissioni_percolato">
        <h2>Report Emissioni e Percolato</h2>

        <!-- FORM FILTRO SOLO PER DATA INIZIO -->
        <form method="GET" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="filtro-date" style="margin-bottom: 20px;">
            <label for="data_inizio">Mostra da data:</label>
            <input type="date" id="data_inizio" name="data_inizio" value="<?php echo htmlspecialchars($data_inizio); ?>" required />

            <button type="submit" class="filtra">Filtra</button>
            <button type="button" class="reset" onclick="window.location.href='<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>'">Reset</button>
        </form>

        <?php if ($result && $result->num_rows > 0): ?>
            <button id="download-pdf-btn">Scarica PDF</button>

            <div class="table-scroll-wrapper">
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>ID Monitoraggio</th>
                            <th>ID Conferimento</th>
                            <th>Tipo Conferimento</th>
                            <th>Data Conferimento</th>
                            <th>Data Rilevazione</th>
                            <th>CO₂ Emessa (kg)</th>
                            <th>Percolato Rilevato (litri)</th>
                            <th>Note</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['ID_monitoraggio']); ?></td>
                            <td><?php echo htmlspecialchars($row['conferimento_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                            <td><?php echo htmlspecialchars($row['data_conferimento']); ?></td>
                            <td><?php echo htmlspecialchars($row['data_rilevazione']); ?></td>
                            <td><?php echo htmlspecialchars($row['co2_emessa']); ?></td>
                            <td><?php echo htmlspecialchars($row['percolato_rilevato']); ?></td>
                            <td><?php echo htmlspecialchars($row['note']); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p>Nessun dato di emissioni e percolato disponibile.</p>
        <?php endif; ?>
    </div>

    <!-- jsPDF e jsPDF AutoTable da CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>

    <script>
        document.getElementById('download-pdf-btn').addEventListener('click', () => {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            doc.setFontSize(14);
            doc.text("Report Emissioni e Percolato", 14, 15);

            doc.autoTable({
                html: '.report-table',
                startY: 25,
                styles: { fontSize: 8 },
                headStyles: { fillColor: [22, 160, 133] },
                margin: { left: 14, right: 14 }
            });

            doc.save('report_emissioni_percolato.pdf');
        });
    </script>
</body>
</html>
