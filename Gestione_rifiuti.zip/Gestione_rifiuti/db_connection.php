<?php
$servername = "localhost";
$username = "root";    // utente predefinito XAMPP
$password = "";        // password vuota di default su XAMPP
$dbname = "gestione rifiuti";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}
?>
