<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'amministratore') {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Genera Report</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <div class="back-dashboard">
        <a href="dashboard_amministratore.php" title="Torna alla Dashboard">← Dashboard</a>
    </div>
    
    <div class="page-flex-container" style="display:flex; gap:40px; align-items:flex-start; padding: 20px;">
        
        <!-- Container originale per report conferimenti -->
        <div class="container" style="flex:1; min-width:300px;">
            <h1>Genera Report Conferimenti</h1>
            <form method="POST" action="processa_report.php">
                <label for="data_inizio">Data Inizio:</label>
                <input type="date" id="data_inizio" name="data_inizio" required />
                <br/><br/>
                <label for="data_fine">Data Fine:</label>
                <input type="date" id="data_fine" name="data_fine" required />
                <br/><br/>
                <button type="submit">Genera Report</button>
            </form>

            <div style="margin-top: 20px;">
                <a href="storico_report.php" style="text-decoration: none; padding: 10px 20px; background-color: #2d6a4f; color: white; border-radius: 6px; display: inline-block;">
                    📄 Visualizza Storico Report
                </a>
            </div>
        </div>

        <!-- Nuovo container per report emissioni e percolato -->
        <div class="container" style="flex:1; min-width:300px; background-color:#f9f9f9; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
            <h1>Genera Report Emissioni e Percolato</h1>
            

            <div style="margin-top: 20px;">
                <a href="storico_report_emissioni_percolato.php" style="text-decoration: none; padding: 10px 20px; background-color: #1b4332; color: white; border-radius: 6px; display: inline-block;">
                    📄 Visualizza Storico Report Emissioni
                </a>
            </div>
        </div>

    </div>
</body>
</html>
