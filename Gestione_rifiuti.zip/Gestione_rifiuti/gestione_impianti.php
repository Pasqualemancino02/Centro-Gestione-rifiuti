<?php
require_once 'db_connection.php';  // include la connessione

// Funzione per sanificare input (semplice)
function clean_input($data) {
    return htmlspecialchars(trim($data));
}

// Gestione inserimento impianto
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'inserisci') {
    $nome = clean_input($_POST['nome']);
    $localita = clean_input($_POST['localita']);
    $tipo_impianto = clean_input($_POST['tipo_impianto']);
    $capacita_massima = floatval($_POST['capacita_massima']);
    $stato = ($_POST['stato'] === 'attivo') ? 'attivo' : 'inattivo';

    $stmt = $conn->prepare("INSERT INTO impianti (nome, localita, tipo_impianto, capacita_massima, stato) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssds", $nome, $localita, $tipo_impianto, $capacita_massima, $stato);

    if ($stmt->execute()) {
        $msg = "Impianto inserito correttamente.";
    } else {
        $msg = "Errore nell'inserimento: " . $stmt->error;
    }
    $stmt->close();
}

// Gestione eliminazione impianto
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM impianti WHERE ID_impianto = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $msg = "Impianto eliminato correttamente.";
    } else {
        $msg = "Errore nell'eliminazione: " . $stmt->error;
    }
    $stmt->close();
}

// Recupero impianti per visualizzazione
$result = $conn->query("SELECT * FROM impianti ORDER BY ID_impianto DESC");
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Gestione Impianti - Amministratore</title>
    <link rel="stylesheet" href="css/style.css" />
    <style>
        /* Stile container */
        .container {
            width: 95%;
            max-width: 900px;
            margin: 40px auto;
            background: #f9f9f9;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
            box-sizing: border-box;
        }

        /* Form con campi più contenuti */
        form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-start;
            margin-bottom: 30px;
        }
        form input[type="text"],
        form input[type="number"],
        form select {
            flex: 1 1 250px;  /* minimo 250px, può crescere */
            max-width: 300px;
            padding: 8px 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        form input[type="submit"] {
            flex: 0 0 auto;
            max-width: 160px;
            padding: 10px 18px;
            font-weight: bold;
            background-color: #2d6a4f;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        form input[type="submit"]:hover {
            background-color: #1b4332;
        }

        /* Titolo */
        h1 {
            text-align: center;
            color: #1b4332;
            margin-bottom: 25px;
        }

        /* Tabella */
        table.report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table.report-table th,
        table.report-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        table.report-table th {
            background-color: #2d6a4f;
            color: white;
        }
        table.report-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table.report-table tr:hover {
            background-color: #e6f2ea;
        }
        table.report-table td:last-child {
            text-align: center;
        }
    </style>
</head>
<body class="dashboard-amministratore">
    <div class="back-dashboard">
        <a href="dashboard_amministratore.php" title="Torna alla Dashboard">← Dashboard</a>
    </div>

    <div class="container">
        <h1>Gestione Impianti</h1>

        <?php if (!empty($msg)): ?>
            <p style="color: green; font-weight: bold;"><?php echo $msg; ?></p>
        <?php endif; ?>

        <!-- Form Inserimento -->
        <form method="POST" action="gestione_impianti.php">
            <input type="hidden" name="action" value="inserisci" />
            <input type="text" name="nome" placeholder="Nome impianto" required />
            <input type="text" name="localita" placeholder="Località" required />
            <input type="text" name="tipo_impianto" placeholder="Tipo impianto" required />
            <input type="number" step="0.01" name="capacita_massima" placeholder="Capacità massima" required />
            <select name="stato" required>
                <option value="attivo">Attivo</option>
                <option value="inattivo">Inattivo</option>
            </select>
            <input type="submit" value="Aggiungi Impianto" />
        </form>

        <hr />

        <!-- Tabella impianti -->
        <table class="report-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Località</th>
                    <th>Tipo Impianto</th>
                    <th>Capacità Massima</th>
                    <th>Stato</th>
                    <th>Azioni</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['ID_impianto']; ?></td>
                        <td><?php echo htmlspecialchars($row['nome']); ?></td>
                        <td><?php echo htmlspecialchars($row['localita']); ?></td>
                        <td><?php echo htmlspecialchars($row['tipo_impianto']); ?></td>
                        <td style="text-align: right;"><?php echo number_format($row['capacita_massima'], 2); ?></td>
                        <td><?php echo $row['stato']; ?></td>
                        <td>
                            <a href="gestione_impianti.php?delete=<?php echo $row['ID_impianto']; ?>" 
                               onclick="return confirm('Sei sicuro di voler eliminare questo impianto?');"
                               style="color: red; text-decoration: none; font-weight: bold;">Elimina</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7" style="text-align:center;">Nessun impianto presente.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php $conn->close(); ?>
