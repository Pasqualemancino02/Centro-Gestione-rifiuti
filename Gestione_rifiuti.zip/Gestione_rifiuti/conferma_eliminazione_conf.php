<?php
session_start();

if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'dipendente') {
    header("Location: login.html");
    exit();
}

require_once 'db_connection.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID conferimento non valido.");
}

$id = (int)$_GET['id'];
$errore = "";
$successo = "";

// Quando il form è inviato
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $motivo = trim($_POST['motivo'] ?? '');

    if (empty($motivo)) {
        $errore = "Devi inserire il motivo dell'eliminazione.";
    } else {
        try {
            $conn->begin_transaction();

            // Inserisci nello storico con la motivazione
            $sql_insert = "INSERT INTO storico_conferimenti (
                ID_conferimento_originale, tipo, data, peso, stato, impianto_id,
                dipendente_id, provenienza, tipo_smaltimento, pericolosita, motivazione_eliminazione
            )
            SELECT 
                ID_conferimento, tipo, data, peso, stato, impianto_id,
                dipendente_id, provenienza, tipo_smaltimento, pericolosita, ?
            FROM conferimenti WHERE ID_conferimento = ?";

            $stmt = $conn->prepare($sql_insert);
            $stmt->bind_param("si", $motivo, $id);
            $stmt->execute();

            // Elimina il conferimento dalla tabella principale
            $sql_delete = "DELETE FROM conferimenti WHERE ID_conferimento = ?";
            $stmt = $conn->prepare($sql_delete);
            $stmt->bind_param("i", $id);
            $stmt->execute();

            $conn->commit();

            $successo = "Conferimento eliminato correttamente e salvato nello storico.";
        } catch (Exception $e) {
            $conn->rollback();
            $errore = "Errore durante l'eliminazione: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Conferma Eliminazione Conferimento</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
      /* Per centrare il form e dare un po' di margine */
      .container {
          max-width: 500px;
          margin: 60px auto;
          background: white;
          padding: 30px;
          border-radius: 10px;
          box-shadow: 0 0 15px rgba(0,0,0,0.1);
          font-family: Arial, sans-serif;
      }
      h1 {
          color: #b02a37;
          text-align: center;
          margin-bottom: 20px;
      }
      label {
          font-weight: bold;
      }
      textarea {
          width: 100%;
          height: 100px;
          margin-top: 8px;
          margin-bottom: 15px;
          padding: 8px;
          font-size: 14px;
          border-radius: 5px;
          border: 1px solid #ccc;
          resize: vertical;
          font-family: Arial, sans-serif;
      }
      .btn {
          background-color: #b02a37;
          color: white;
          padding: 10px 20px;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 16px;
          transition: background-color 0.3s;
      }
      .btn:hover {
          background-color: #7c1a25;
      }
      .msg-error {
          background-color: #f8d7da;
          color: #721c24;
          padding: 10px;
          border-radius: 5px;
          margin-bottom: 15px;
      }
      .msg-success {
          background-color: #d4edda;
          color: #155724;
          padding: 10px;
          border-radius: 5px;
          margin-bottom: 15px;
          text-align: center;
      }
      .link-center {
          text-align: center;
          margin-top: 20px;
      }
      .link-center a {
          text-decoration: none;
          color: #2d6a4f;
          font-weight: bold;
      }
      .link-center a:hover {
          text-decoration: underline;
      }
    </style>
</head>
<body>

<div class="container">
    <h1>Eliminazione Conferimento</h1>

    <?php if ($errore): ?>
        <div class="msg-error"><?= htmlspecialchars($errore) ?></div>
    <?php endif; ?>

    <?php if ($successo): ?>
        <div class="msg-success"><?= htmlspecialchars($successo) ?></div>
        <div class="link-center">
            <a href="visualizza_miei_conferimenti.php">⬅ Torna alla lista conferimenti</a>
        </div>
    <?php else: ?>
        <form method="post" action="conferma_eliminazione_conf.php?id=<?= $id ?>">
            <label for="motivo">Motivo dell'eliminazione:</label>
            <textarea id="motivo" name="motivo" required></textarea>
            <button type="submit" class="btn">Conferma Eliminazione</button>
        </form>
        <div class="link-center">
            <a href="visualizza_miei_conferimenti.php">Annulla e torna indietro</a>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
