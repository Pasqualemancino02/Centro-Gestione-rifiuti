<?php
$conn = new mysqli("localhost", "root", "", "gestione rifiuti");

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$messaggio = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"] ?? '';
    $new_password = $_POST["new_password"] ?? '';

    if (!empty($email) && !empty($new_password)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE utenti SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashed_password, $email);

        if ($stmt->execute()) {
            $messaggio = "Password aggiornata con successo.";
        } else {
            $messaggio = "Errore nell'aggiornamento della password.";
        }
    } else {
        $messaggio = "Campi mancanti.";
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Password Aggiornata - Centro Gestione Rifiuti</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <div class="container" style="max-width: 400px; margin-top: 100px; text-align: center;">
        <img src="img/logo.png" alt="Logo Centro Gestione Rifiuti" class="logo" />
        <h1>Reset Password</h1>
        <p><?= htmlspecialchars($messaggio) ?></p>
        <a class="btn" href="login.html">Torna al login</a>
    </div>
</body>
</html>

