<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'amministratore') {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once("db_connection.php");

    $data_inizio = $_POST['data_inizio'];
    $data_fine = $_POST['data_fine'];

    if (!$data_inizio || !$data_fine || $data_inizio > $data_fine) {
        die("Intervallo di date non valido.");
    }

    $sql = "SELECT ID_conferimento, tipo, data, peso, stato, impianto_id, dipendente_id, provenienza, tipo_smaltimento, pericolosita 
            FROM conferimenti 
            WHERE data BETWEEN ? AND ?
            ORDER BY data ASC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $data_inizio, $data_fine);
    $stmt->execute();
    $result = $stmt->get_result();

    // Dati fissi e dinamici per PDF
    $nome_ditta = "Centro Gestione Rifiuti S.r.l.";
    $admin_email = $_SESSION['email'];
    $admin_nome = isset($_SESSION['nome']) ? $_SESSION['nome'] : $admin_email;

    // Inizializzo sempre l'array rows_js per evitare warning
    $rows_js = [];

    // Output HTML
    echo '<!DOCTYPE html>
    <html lang="it">
 <head>
    <meta charset="UTF-8">
    <title>Report Conferimenti</title>
    <link rel="stylesheet" href="css/style.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
 </head>
 <body class="dashboard-amministratore">

 

 <div class="back-dashboard">
  <a href="genera_report.php">&larr; Torna indietro</a>
 </div>

 <div class="report-container">
  <h2>Report Conferimenti dal ' . htmlspecialchars($data_inizio) . ' al ' . htmlspecialchars($data_fine) . '</h2>';

    if ($result->num_rows > 0) {
        echo '<button id="download-pdf" style="margin-bottom: 15px; padding: 8px 16px; background-color: #2d6a4f; color: white; border: none; border-radius: 6px; cursor: pointer;">Scarica Report PDF</button>';

        echo '<table class="report-table" id="report-table">';
        echo "<thead>
                <tr>
                    <th>ID</th>
                    <th>Tipo</th>
                    <th>Data</th>
                    <th>Peso</th>
                    <th>Stato</th>
                    <th>Impianto ID</th>
                    <th>Dipendente ID</th>
                    <th>Provenienza</th>
                    <th>Tipo Smaltimento</th>
                    <th>Pericolosità</th>
                </tr>
              </thead>";
        echo "<tbody>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['ID_conferimento']}</td>
                    <td>{$row['tipo']}</td>
                    <td>{$row['data']}</td>
                    <td>{$row['peso']}</td>
                    <td>{$row['stato']}</td>
                    <td>{$row['impianto_id']}</td>
                    <td>{$row['dipendente_id']}</td>
                    <td>{$row['provenienza']}</td>
                    <td>{$row['tipo_smaltimento']}</td>
                    <td>{$row['pericolosita']}</td>
                  </tr>";

            $rows_js[] = [
                $row['ID_conferimento'], $row['tipo'], $row['data'], $row['peso'], $row['stato'],
                $row['impianto_id'], $row['dipendente_id'], $row['provenienza'], $row['tipo_smaltimento'], $row['pericolosita']
            ];
        }
        echo "</tbody></table>";
    } else {
        echo "<p>Nessun conferimento trovato in questo intervallo di date.</p>";
    }

    echo '</div>

<script>
  /* Aggiungo controllo per mostrare bottone solo se ci sono dati */
  const rows = ' . json_encode($rows_js) . ';
  if(rows.length > 0) {
    document.getElementById("download-pdf").addEventListener("click", function() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();

      const nomeDitta = "' . addslashes($nome_ditta) . '";
      const adminNome = "' . addslashes($admin_nome) . '";
      const dataInizio = "' . addslashes($data_inizio) . '";
      const dataFine = "' . addslashes($data_fine) . '";

      const columns = ["ID", "Tipo", "Data", "Peso", "Stato", "Impianto ID", "Dipendente ID", "Provenienza", "Tipo Smaltimento", "Pericolosità"];

      doc.setFontSize(14);
      doc.text(nomeDitta, 14, 15);
      doc.setFontSize(11);
      doc.text("Report Conferimenti dal " + dataInizio + " al " + dataFine, 14, 22);
      doc.text("Generato da: " + adminNome, 14, 29);

      doc.autoTable({
        startY: 35,
        head: [columns],
        body: rows,
        styles: { fontSize: 8 },
        headStyles: { fillColor: [45, 106, 79] },
        alternateRowStyles: { fillColor: [240, 249, 244] }
      });

      doc.save("report_conferimenti_' . str_replace("-", "", $data_inizio) . '_al_' . str_replace("-", "", $data_fine) . '.pdf");
    });
  }
</script>

</body>
</html>';

    // Salvataggio nel DB nella tabella "report"
    $email = $_SESSION['email'];
    $sql_utente = "SELECT id FROM utenti WHERE email = ?";
    $stmt_utente = $conn->prepare($sql_utente);
    $stmt_utente->bind_param("s", $email);
    $stmt_utente->execute();
    $result_utente = $stmt_utente->get_result();

    if ($row_utente = $result_utente->fetch_assoc()) {
        $utente_id = $row_utente['id'];

        $sql_insert = "INSERT INTO report (utente_id, filtro_data_inizio, filtro_data_fine, data_generazione, percorso_file, note)
                       VALUES (?, ?, ?, NOW(), ?, ?)";

        $percorso_file = "report_conferimenti_" . str_replace("-", "", $data_inizio) . "_al_" . str_replace("-", "", $data_fine) . ".pdf";
        $note = "Report generato da $admin_nome";

        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("issss", $utente_id, $data_inizio, $data_fine, $percorso_file, $note);
        $stmt_insert->execute();
    }

    $stmt->close();
    $stmt_utente->close();
    if (isset($stmt_insert)) {
        $stmt_insert->close();
    }
    $conn->close();
} else {
    header("Location: genera_report.php");
    exit();
}
?>
