<?php
require_once 'db_connection.php';  // Connessione al DB

$query = "SELECT * FROM storico_manutenzioni ORDER BY data_azione DESC";
$result = $conn->query($query);

if (!$result) {
    die("Errore nella query: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Storico Manutenzioni</title>
    <link rel="stylesheet" href="css/style.css" />
    <style>
      .storico-container {
        width: 95%;
        max-width: 1200px;
        margin: 40px auto;
        background: rgba(255,255,255,0.95);
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
        box-sizing: border-box;
        overflow-x: auto;
      }

      .storico-container table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        white-space: nowrap;
      }

      .storico-container th, 
      .storico-container td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
        word-break: break-word;
      }

      .storico-container th {
        background-color: #2d6a4f;
        color: white;
      }

      .storico-container tr:nth-child(even) {
        background-color: #f9f9f9;
      }

      .storico-container tr:hover {
        background-color: #e6f2ea;
      }
    </style>
</head>
<body>

<div class="back-dashboard">
    <a href="pianificazione_impianti.php" title="Torna a Gestione Turnazioni">← Torna indietro</a>
</div>

<div class="container storico-container">
    <h1>Storico Manutenzioni</h1>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>ID Manutenzione</th>
          <th>Azione</th>
          <th>Data Azione</th>
          <th>Dati Precedenti</th>
          <th>Note Azione</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?php echo htmlspecialchars($row['id']); ?></td>
              <td><?php echo htmlspecialchars($row['id_manutenzione']); ?></td>
              <td><?php echo htmlspecialchars($row['azione']); ?></td>
              <td><?php echo htmlspecialchars($row['data_azione']); ?></td>
              <td><?php echo nl2br(htmlspecialchars($row['dati_precedenti'])); ?></td>
              <td><?php echo nl2br(htmlspecialchars($row['note_azione'])); ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="6" style="text-align:center;">Nessun dato trovato</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
</div>

</body>
</html>

<?php
$conn->close();
?>
