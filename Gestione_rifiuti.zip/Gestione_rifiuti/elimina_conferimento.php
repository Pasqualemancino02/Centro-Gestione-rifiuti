<?php
session_start();

require_once 'db_connection.php'; // connessione mysqli già pronta

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID conferimento non valido");
}

$id = (int)$_GET['id'];

try {
    // Avvia transazione
    $conn->begin_transaction();

    // 1. Inserisco nello storico usando mysqli prepare
    $sql_insert = "INSERT INTO storico_conferimenti (
        ID_conferimento_originale,
        tipo,
        data,
        peso,
        stato,
        impianto_id,
        dipendente_id,
        provenienza,
        tipo_smaltimento,
        pericolosita,
        motivazione_eliminazione
    )
    SELECT 
        ID_conferimento,
        tipo,
        data,
        peso,
        stato,
        impianto_id,
        dipendente_id,
        provenienza,
        tipo_smaltimento,
        pericolosita,
        'Eliminazione da parte dell\'utente'
    FROM conferimenti WHERE ID_conferimento = ?";

    $stmt = $conn->prepare($sql_insert);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // 2. Elimino il conferimento dalla tabella principale
    $sql_delete = "DELETE FROM conferimenti WHERE ID_conferimento = ?";
    $stmt = $conn->prepare($sql_delete);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Commit transazione
    $conn->commit();

    $messaggio = "Conferimento eliminato correttamente e salvato nello storico.";
} catch (Exception $e) {
    $conn->rollback();
    $messaggio = "Errore durante l'eliminazione: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>Eliminazione Conferimento</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1>Eliminazione Conferimento</h1>
    <p><?= htmlspecialchars($messaggio) ?></p>
    <a href="visualizza_miei_conferimenti.php" class="btn">Torna alla lista</a>
</div>
</body>
</html>

