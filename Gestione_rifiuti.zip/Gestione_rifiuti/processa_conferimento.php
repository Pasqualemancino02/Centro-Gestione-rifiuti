<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'dipendente') {
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "gestione rifiuti");
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Prendo i dati dal form
$tipo = $_POST['tipo'] ?? '';
$data = $_POST['data'] ?? '';
$peso = $_POST['peso'] ?? 0;
$stato = $_POST['stato'] ?? '';
$impianto_id = $_POST['impianto_id'] ?? 0;
$provenienza = $_POST['provenienza'] ?? '';
$tipo_smaltimento = $_POST['tipo_smaltimento'] ?? '';
$pericolosita = $_POST['pericolosita'] ?? '';
$dipendente_id = null;

// Prendo l'id del dipendente (utente loggato)
$email = $_SESSION['email'];
$stmt = $conn->prepare("SELECT ID FROM utenti WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($dipendente_id);
$stmt->fetch();
$stmt->close();

if (!$dipendente_id) {
    die("Utente non trovato.");
}

// Inserisco il conferimento nel DB
$stmt = $conn->prepare("INSERT INTO conferimenti (tipo, data, peso, stato, impianto_id, dipendente_id, provenienza, tipo_smaltimento, pericolosita) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssdsissss", $tipo, $data, $peso, $stato, $impianto_id, $dipendente_id, $provenienza, $tipo_smaltimento, $pericolosita);
?>

<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8" />
  <title>Inserimento Conferimento - Centro Gestione Rifiuti</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <div class="container">
    <?php if ($stmt->execute()): ?>
      <h1>Conferimento inserito con successo!</h1>
      <p>Il tuo conferimento è stato registrato correttamente.</p>
      <a href="inserisci_conferimento.php" class="button">Inserisci un altro conferimento</a>
      <a href="dashboard_dipendente.php" class="button">Torna alla Dashboard</a>
    <?php else: ?>
      <h1>Errore durante l'inserimento</h1>
      <p><?= htmlspecialchars($stmt->error) ?></p>
      <a href="inserisci_conferimento.php" class="button">Riprova</a>
      <a href="dashboard_dipendente.php" class="button">Torna alla Dashboard</a>
    <?php endif; ?>
  </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
