<?php 
session_start();
require_once 'db_connection.php';

$error = '';
$success = '';

// Carica lista impianti attivi per select
$impianti = [];
$sql = "SELECT ID_impianto, nome FROM impianti WHERE stato = 'attivo' ORDER BY nome";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $impianti[] = $row;
    }
} else {
    $error = "Errore nel caricamento degli impianti.";
}

// Gestione submit form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_impianto = $_POST['id_impianto'] ?? '';
    $data_inizio = $_POST['data_inizio'] ?? '';
    $data_fine = $_POST['data_fine'] ?? '';
    $note = trim($_POST['note'] ?? '');
    $tipo_turno = $_POST['tipo_turno'] ?? '';

    // Validazioni base
    if (!$id_impianto || !$data_inizio || !$data_fine || !$tipo_turno) {
        $error = "Tutti i campi obbligatori devono essere compilati.";
    } elseif ($data_inizio > $data_fine) {
        $error = "La data di inizio non può essere successiva alla data di fine.";
    } elseif (!in_array($tipo_turno, ['mattina', 'pomeriggio', 'notte'])) {
        $error = "Tipo turno non valido.";
    } else {
        // Controlla se id_impianto esiste e attivo
        $stmt = $conn->prepare("SELECT COUNT(*) FROM impianti WHERE ID_impianto = ? AND stato = 'attivo'");
        $stmt->bind_param('i', $id_impianto);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        if ($count == 0) {
            $error = "Impianto selezionato non valido o non attivo.";
        } else {
            // Inserisci nella tabella turnazioni (aggiunto campo tipo_turno)
            $stmt = $conn->prepare("INSERT INTO turnazioni (id_impianto, data_inizio, data_fine, tipo_turno, note) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param('issss', $id_impianto, $data_inizio, $data_fine, $tipo_turno, $note);
            if ($stmt->execute()) {
                $success = "Turnazione inserita con successo.";
                // Reset campi form dopo inserimento
                $_POST = [];
            } else {
                $error = "Errore durante il salvataggio della turnazione.";
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Gestione Turnazione Impianti</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body class="dashboard-amministratore">

<div class="back-dashboard" style="margin-bottom:20px;">
    <a href="pianificazione_impianti.php" title="Torna a Pianificazione Impianti">← Torna indietro</a>
</div>

<div class="container" style="background-color: rgba(255,255,255,0.9); max-width: 600px; margin: auto; padding: 20px; border-radius: 8px;">
    <h1>Nuova Turnazione Impianto</h1>

    <?php if ($error): ?>
        <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success-msg"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form method="post" action="turnazione_impianti.php" class="form-turnazione">
        <label for="id_impianto">Seleziona Impianto <span style="color:red;">*</span></label>
        <select name="id_impianto" id="id_impianto" required>
            <option value="">-- Scegli Impianto --</option>
            <?php foreach ($impianti as $impianto): ?>
                <option value="<?php echo $impianto['ID_impianto']; ?>"
                    <?php if (isset($_POST['id_impianto']) && $_POST['id_impianto'] == $impianto['ID_impianto']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($impianto['nome']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="data_inizio">Data Inizio <span style="color:red;">*</span></label>
        <input type="date" name="data_inizio" id="data_inizio" required
               value="<?php echo isset($_POST['data_inizio']) ? htmlspecialchars($_POST['data_inizio']) : ''; ?>" />

        <label for="data_fine">Data Fine <span style="color:red;">*</span></label>
        <input type="date" name="data_fine" id="data_fine" required
               value="<?php echo isset($_POST['data_fine']) ? htmlspecialchars($_POST['data_fine']) : ''; ?>" />

        <label for="tipo_turno">Tipo Turno <span style="color:red;">*</span></label>
        <select name="tipo_turno" id="tipo_turno" required>
            <option value="">-- Seleziona --</option>
            <option value="mattina" <?php if (isset($_POST['tipo_turno']) && $_POST['tipo_turno'] == 'mattina') echo 'selected'; ?>>Mattina</option>
            <option value="pomeriggio" <?php if (isset($_POST['tipo_turno']) && $_POST['tipo_turno'] == 'pomeriggio') echo 'selected'; ?>>Pomeriggio</option>
            <option value="notte" <?php if (isset($_POST['tipo_turno']) && $_POST['tipo_turno'] == 'notte') echo 'selected'; ?>>Notte</option>
        </select>

        <label for="note">Note</label>
        <textarea name="note" id="note" rows="3"><?php echo isset($_POST['note']) ? htmlspecialchars($_POST['note']) : ''; ?></textarea>

        <button type="submit" class="btn" style="margin-top: 15px;">Salva Turnazione</button>
    </form>
</div>

</body>
</html>
