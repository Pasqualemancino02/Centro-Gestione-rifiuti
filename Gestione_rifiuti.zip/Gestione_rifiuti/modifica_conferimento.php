<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['ruolo'] !== 'dipendente') {
    header("Location: login.html");
    exit();
}

require_once 'db_connection.php';

if (!isset($_GET['id'])) {
    die("ID conferimento non specificato.");
}

$id = intval($_GET['id']);

// Prendo impianti attivi per select
$sql_impianti = "SELECT ID_impianto, nome FROM impianti WHERE stato = 'attivo'";
$result_impianti = $conn->query($sql_impianti);

// Se il form è stato inviato, aggiorna il conferimento
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['tipo'] ?? '';
    $data = $_POST['data'] ?? '';
    $peso = $_POST['peso'] ?? '';
    $stato = $_POST['stato'] ?? '';
    $impianto_id = $_POST['impianto_id'] ?? '';

    $provenienza = $_POST['provenienza'] ?? '';
    $tipo_smaltimento = $_POST['tipo_smaltimento'] ?? '';
    $pericolosita = $_POST['pericolosita'] ?? '';

    $stmt = $conn->prepare("UPDATE conferimenti SET tipo = ?, data = ?, peso = ?, stato = ?, impianto_id = ?, provenienza = ?, tipo_smaltimento = ?, pericolosita = ? WHERE ID_conferimento = ?");
    $stmt->bind_param("ssdsssssi", $tipo, $data, $peso, $stato, $impianto_id, $provenienza, $tipo_smaltimento, $pericolosita, $id);

    if ($stmt->execute()) {
        header("Location: visualizza_miei_conferimenti.php?msg=modifica_successo");
        exit();
    } else {
        $error = "Errore durante l'aggiornamento: " . $conn->error;
    }
}

// Carica dati conferimento da mostrare nel form
$stmt = $conn->prepare("SELECT tipo, data, peso, stato, impianto_id, provenienza, tipo_smaltimento, pericolosita FROM conferimenti WHERE ID_conferimento = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Conferimento non trovato.");
}

$conferimento = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8" />
<title>Modifica Conferimento</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>

<div class="back-dashboard">
        <a href="visualizza_miei_conferimenti.php" title="Miei conferimenti">← Torna a Genera Report</a>
    </div>

    <div class="container">
        <h1>Modifica Conferimento #<?= htmlspecialchars($id) ?></h1>
        <?php if (!empty($error)): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <form action="" method="POST">
            <input type="hidden" name="ID_conferimento" value="<?= htmlspecialchars($id) ?>">

            <label for="tipo">Tipo conferimento:</label><br>
            <select id="tipo" name="tipo" required>
                <option value="">-- Seleziona tipo --</option>
                <?php
                $tipi = ['Plastica', 'Vetro', 'Carta', 'Organico', 'Indifferenziato'];
                foreach ($tipi as $tipoOption) {
                    $selected = ($conferimento['tipo'] === $tipoOption) ? 'selected' : '';
                    echo "<option value=\"$tipoOption\" $selected>$tipoOption</option>";
                }
                ?>
            </select><br><br>

            <label for="data">Data conferimento:</label><br>
            <input type="date" id="data" name="data" value="<?= htmlspecialchars($conferimento['data']) ?>" required><br><br>

            <label for="peso">Peso (kg):</label><br>
            <input type="number" id="peso" name="peso" step="0.01" min="0" value="<?= htmlspecialchars($conferimento['peso']) ?>" required><br><br>

            <label for="stato">Stato:</label><br>
            <select id="stato" name="stato" required>
                <?php
                $stati = ['in attesa', 'processato', 'completato'];
                foreach ($stati as $statoOption) {
                    $selected = ($conferimento['stato'] === $statoOption) ? 'selected' : '';
                    echo "<option value=\"$statoOption\" $selected>" . ucfirst($statoOption) . "</option>";
                }
                ?>
            </select><br><br>

            <label for="impianto">Impianto:</label><br>
            <select id="impianto" name="impianto_id" required>
                <option value="">-- Seleziona Impianto --</option>
                <?php
                if ($result_impianti->num_rows > 0) {
                    while ($row = $result_impianti->fetch_assoc()) {
                        $selected = ($conferimento['impianto_id'] == $row['ID_impianto']) ? 'selected' : '';
                        echo '<option value="' . $row['ID_impianto'] . '" ' . $selected . '>' . htmlspecialchars($row['nome']) . '</option>';
                    }
                }
                ?>
            </select><br><br>

            <label for="provenienza">Provenienza:</label><br>
            <input type="text" id="provenienza" name="provenienza" value="<?= htmlspecialchars($conferimento['provenienza']) ?>"><br><br>

            <label for="tipo_smaltimento">Tipo Smaltimento:</label><br>
            <select id="tipo_smaltimento" name="tipo_smaltimento" required>
                <option value="">-- Seleziona tipo smaltimento --</option>
                <option value="Riciclaggio">Riciclaggio</option>
                <option value="Discarica">Discarica</option>
                <option value="Incenerimento">Incenerimento</option>
            </select><br><br>
            

            <label for="pericolosita">Pericolosità:</label><br>
            <select id="pericolosita" name="pericolosita" required>
                <option value="">-- Seleziona pericolosità --</option>
                <option value="no">NO</option>
                <option value="si">SI</option>
            </select><br><br>
            

            <input type="submit" value="Aggiorna Conferimento">
        </form>
        <br>
        <a href="dashboard_dipendente.php">Torna alla Dashboard</a>
    </div>
</body>

</html>


