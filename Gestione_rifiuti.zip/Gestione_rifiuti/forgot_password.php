<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <title>Centro Gestione Rifiuti - Recupero Password</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <!-- Pulsante Ritorna alla home -->
    <div class="back-home">
      <a href="homepage.html" title="Ritorna alla home">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#2d6a4f" viewBox="0 0 24 24">
          <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
        </svg>
      </a>
    </div>

    <!-- conteiner con l'inserimento email per il cambio password -->
    <div class="container">
        <img src="img/logo.png" alt="Logo Centro Gestione Rifiuti" class="logo" />
        <h1>Recupero Password</h1>
        <form action="reset_password.php" method="POST">
            <input type="email" name="email" placeholder="Inserisci la tua email" required />
            <input type="submit" value="Recupera Password" />
        </form>
        <div class="links">
            <a href="login.html">Torna al login</a><br />
            <a href="registrazione.html">Non hai un account? Registrati</a>
        </div>
    </div>
</body>
</html>
